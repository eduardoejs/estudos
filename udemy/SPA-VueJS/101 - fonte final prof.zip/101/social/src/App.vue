<template>

    <router-view/>

</template>

<script>


export default {
  name: 'app',
  components:{
    
  }
}
</script>

<style>

</style>
